import 'package:algraphy/modules/signature/presentation/pages/document_management_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb; 
import '../views/registration_stepper_view.dart';
import '../../../../modules/common/widgets/coming_soon_page.dart';
import 'all_employees_page.dart'; 

class EmployeeManagementPage extends StatefulWidget {
  final bool isAdmin;
  final int initialIndex;

  const EmployeeManagementPage({
    super.key,
    required this.isAdmin,
    this.initialIndex = 0,
  });

  @override
  State<EmployeeManagementPage> createState() => _EmployeeManagementPageState();
}

class _EmployeeManagementPageState extends State<EmployeeManagementPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  late List<String> _tabs;

  @override
  void initState() {
    super.initState();
    _setupTabs();
    
    int startIndex = widget.initialIndex;
    if (startIndex >= _tabs.length) startIndex = 0;

    _tabController = TabController(
      length: _tabs.length,
      vsync: this,
      initialIndex: startIndex,
    );
  }

  void _setupTabs() {
    if (widget.isAdmin) {
      _tabs = ["Directory", "Onboarding", "Org Tree", "Documents"];
    } else {
      // FIX: Added Documents to the labels list to match the views list length
      _tabs = ["Directory", "Org Tree", "Documents"];
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const Color backgroundDark = Color(0xFF080808);
    const Color primaryRed = Color(0xFFDC2726);

    return Column(
      children: [
        Container(
          color: backgroundDark,
          width: double.infinity,
          child: TabBar(
            controller: _tabController,
            isScrollable: true, 
            indicatorColor: primaryRed,
            indicatorWeight: 3,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.grey,
            labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.normal, fontSize: 15),
            dividerColor: Colors.transparent, 
            tabAlignment: TabAlignment.start,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            labelPadding: const EdgeInsets.only(right: 24),
            tabs: _tabs.map((tab) => Tab(text: tab)).toList(),
          ),
        ),

        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: _buildTabViews(),
          ),
        ),
      ],
    );
  }

  List<Widget> _buildTabViews() {
    List<Widget> views = [
      const AllEmployeesPage(), 
    ];

    if (widget.isAdmin) {
      // Admin Views
      if (kIsWeb) {
        views.add(const RegistrationStepperView()); 
      } else {
        views.add(const _MobileOnboardingRestrictedView());
      }
      views.add(const ComingSoonPage(title: "Organization Tree"));
      views.add(const DocumentManagementPage(isAdmin: true));
    } else {
      // Non-Admin Views (Now matches the 3 tabs defined in _setupTabs)
      views.add(const ComingSoonPage(title: "Organization Tree"));
      views.add(const DocumentManagementPage(isAdmin: false));
    }

    return views;
  }
}

class _MobileOnboardingRestrictedView extends StatelessWidget {
  const _MobileOnboardingRestrictedView();
  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text("Web Portal Only", style: TextStyle(color: Colors.white, fontSize: 18)),
    );
  }
}